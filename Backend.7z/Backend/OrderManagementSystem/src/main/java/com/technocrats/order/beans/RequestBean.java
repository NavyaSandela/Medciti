package com.technocrats.order.beans;

import java.util.List;

public class RequestBean {
	int userId;
	List<String> products;
	String purchaseDate;
	
}
