package com.loginManagement.loginSecure.order.bean;

import java.util.List;

public class RequestBean {
	int userId;
	List<String> products;
	String purchaseDate;
	
}
