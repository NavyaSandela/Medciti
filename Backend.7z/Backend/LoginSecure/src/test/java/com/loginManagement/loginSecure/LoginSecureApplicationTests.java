package com.loginManagement.loginSecure;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LoginSecureApplicationTests {

	@Test
	void contextLoads() {
	}

}
